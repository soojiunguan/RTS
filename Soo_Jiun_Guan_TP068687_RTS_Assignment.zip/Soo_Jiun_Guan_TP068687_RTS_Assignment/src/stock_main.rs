//stock_main.rs
mod connection; // 引入你的 Connection 文件模块
mod price;
mod orderbook;
mod trader;

use crate::connection::RabbitMQService;
use crate::price::stock_information;
use crate::orderbook::Order;
use lapin::{options::*, types::FieldTable, BasicProperties};
use serde_json;
use tokio;
use futures_lite::StreamExt;
use anyhow;
use std::sync::{Arc, Mutex, atomic::{AtomicBool, Ordering}};
use crate::orderbook::OrderBook;
use std::collections::HashMap;
use chrono::Local; 


async fn producer_workflow(stop_signal: Arc<AtomicBool>) -> anyhow::Result<()> {
    // 使用 connection 文件创建通道
    let channel = RabbitMQService::new().await.get_channel();

    // Declare a queue for stock market data
    channel
        .queue_declare("stock_market", QueueDeclareOptions::default(), FieldTable::default())
        .await?;

    // Declare the orders queue
    channel
        .queue_declare("orders", QueueDeclareOptions::default(), FieldTable::default())
        .await?;

    // 创建共享的 OrderBook
    let order_book = Arc::new(Mutex::new(OrderBook::new(vec![], HashMap::new())));
    let start_time = tokio::time::Instant::now(); // Record the start time

    while !stop_signal.load(Ordering::Relaxed) {
        // Send stock market data
        if start_time.elapsed() >= tokio::time::Duration::from_secs(60) {
            println!("⏳ 60 seconds have passed. Stopping producer...");
            break;
        }
        let stocks = stock_information();
        let stocks_json = serde_json::to_string(&stocks)
            .map_err(|e| anyhow::anyhow!("Failed to serialize stock data: {:?}", e))?;

        channel
            .basic_publish(
                "",
                "stock_market", // Target the 'stock_market' queue
                BasicPublishOptions::default(),
                stocks_json.as_bytes(),
                BasicProperties::default(),
            )
            .await
            .map_err(|e| anyhow::anyhow!("Failed to publish message: {:?}", e))?;
        let current_time = Local::now();
        
        println!("{} 📤 Stocks sent!", current_time.format("%Y-%m-%d %H:%M:%S"));

        // 调用订单处理方法
        let order_book_clone = order_book.clone();
        tokio::spawn(async move {
            if let Err(e) = process_orders(order_book_clone).await {
                eprintln!("Error processing orders: {:?}", e);
            }
        });

        // 模拟生产者的时间间隔
        tokio::time::sleep(tokio::time::Duration::from_secs(5)).await;
    }

    println!("⏳ Stopping producer workflow...");
    Ok(())
}

// 新增方法：在每次股票更新后立即处理订单
async fn process_orders(order_book: Arc<Mutex<OrderBook>>) -> anyhow::Result<()> {
    let channel = RabbitMQService::new().await.get_channel();

    // Declare the queue
    channel
        .queue_declare("orders", QueueDeclareOptions::default(), FieldTable::default())
        .await?;

    let mut consumer = channel
        .basic_consume(
            "orders",
            "order_consumer",
            BasicConsumeOptions::default(),
            FieldTable::default(),
        )
        .await?;

    println!("🛒 Order processing started!");

    // Create a channel for decoupling
    use tokio::sync::mpsc;

    let (order_tx, mut order_rx) = mpsc::channel(100); // Adjust channel size as needed

    // **Producer Task: Receiving Orders**
    tokio::spawn(async move {
        while let Some(delivery) = consumer.next().await {
            let delivery = delivery.expect("Error in consumer");

            let order: Order = match serde_json::from_slice(&delivery.data) {
                Ok(order) => order,
                Err(e) => {
                    eprintln!("Failed to deserialize order: {:?}", e);
                    continue;
                }
            };

            println!("📥 Received order: {:?}", order);

            // Send the order to the matching worker
            if order_tx.send(order).await.is_err() {
                eprintln!("Failed to send order to matching worker");
            }

            // Acknowledge the message
            channel
                .basic_ack(delivery.delivery_tag, BasicAckOptions::default())
                .await
                .expect("Failed to acknowledge order");
        }
    });

    // **Matching Worker Task**
    tokio::spawn(async move {
        while let Some(order) = order_rx.recv().await {
            let mut book = order_book.lock().unwrap();
            book.add_order(order); // Calls match_orders internally
        }
    });

    Ok(())
}


#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let stop_signal = Arc::new(AtomicBool::new(false));
    let stop_signal_clone = stop_signal.clone();

    // 启动生产者任务
    let producer_handle = tokio::spawn(async move {
        if let Err(e) = producer_workflow(stop_signal_clone).await {
            eprintln!("Error in producer workflow: {:?}", e);
        }
    });

    // 等待生产者任务完成
    if let Err(e) = producer_handle.await {
        eprintln!("Producer workflow ended with error: {:?}", e);
    }

    stop_signal.store(true, Ordering::Relaxed); // 设置停止信号
    println!("✅ Producer stopped successfully.");
    Ok(())
}
