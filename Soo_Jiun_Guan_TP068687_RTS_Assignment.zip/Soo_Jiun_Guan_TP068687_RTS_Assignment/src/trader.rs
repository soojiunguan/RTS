//trader.rs
use lapin::options::BasicPublishOptions; 
use lapin::BasicProperties;             

use crate::price::Stock;
use std::collections::HashMap;
use rand::{seq::SliceRandom, Rng};
use std::sync::{Arc, Mutex, atomic::{AtomicBool, Ordering}};
use std::fmt;
use chrono::Utc;
use crate::orderbook::{Order, OrderType};
use serde::{Serialize, Deserialize};

#[derive(Serialize, Deserialize, Debug, Clone)]
pub enum Action {
    Buy,
    Sell,
}

#[derive(Serialize, Deserialize, Debug)]
pub enum Trigger {
    BuyTrigger(f64),
    SellTrigger(f64),
}

impl fmt::Display for Trigger {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Trigger::BuyTrigger(value) => write!(f, "Buy Trigger: ${:.2}", value),
            Trigger::SellTrigger(value) => write!(f, "Sell Trigger: ${:.2}", value),
        }
    }
}

#[derive(Serialize, Deserialize, Debug)]
pub struct TradeAction {
    pub trader_id: usize,
    pub stock_name: String,
    pub action: Action,
    pub trigger: Trigger,
    pub quantity: usize,
}

pub enum TraderError {
    StockNotFound(String),
    BudgetTooLow {
        trader_id: usize,
        stock_name: String,
    },
    ProfitIsLow {
        trader_id: usize,
        stock_name: String,
        paid_price: f64,
        current_price: f64,
    },
    PortfolioEmpty,
}

impl fmt::Display for TraderError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            TraderError::StockNotFound(stock_name) => write!(f, "Stock {} not found.", stock_name),
            TraderError::BudgetTooLow { trader_id, stock_name } => write!(
                f, "Trader {}'s budget for stock <{}> is too low. Not proceeding with the purchase.",
                trader_id, stock_name
            ),
            TraderError::ProfitIsLow { trader_id, stock_name, paid_price, current_price } => write!(
                f, 
                "Trader {} encountered a low profit situation for stock <{}>: previous purchase price was {:.2}, current price is {:.2}. 
                As a result, the trader decided not to proceed.",
                trader_id, stock_name, paid_price, current_price
            ),            
            TraderError::PortfolioEmpty => write!(f, "Portfolio is empty."),
        }
    }
}

#[derive(Clone)] //benchmark use
pub struct Trader {
    pub id: usize,
    pub stocks: Arc<Mutex<Vec<Stock>>>,
    pub portfolio: HashMap<String, (usize, f64)>,
    pub rabbitmq_channel: Arc<lapin::Channel>, // RabbitMQ 通道
    timestamp: i64,
}

impl Trader {
    pub fn new(id: usize, stocks: Arc<Mutex<Vec<Stock>>>, rabbitmq_channel: Arc<lapin::Channel>) -> Self {
        let mut rng = rand::thread_rng();
        let mut portfolio = HashMap::new();
        {
            let stock_market: std::sync::MutexGuard<'_, Vec<Stock>> = stocks.lock().unwrap();
            let num_stocks = rng.gen_range(5..=15);
            for stock in stock_market.choose_multiple(&mut rng, num_stocks) {
                let quantity = rng.gen_range(20..=50);
                let paid_price = rng.gen_range(100.0..=250.0);
                portfolio.insert(stock.name.clone(), (quantity, paid_price));
            }
        }
            println!("Trader {} initialized with portfolio:", id);
            for (stock, (quantity, price)) in &portfolio {
            println!("  - {}: {} shares bought at ${:.2} each", stock, quantity, price);
            }
        Self {
            id,
            stocks,
            portfolio,
            rabbitmq_channel,
            timestamp: Utc::now().timestamp_millis(),
        }
    }
    pub fn start(&mut self, stop_signal: Arc<AtomicBool>) {
        while !stop_signal.load(Ordering::Relaxed) {
            // Perform trading actions
            let actions = self.select_random_stocks();
    
            for (action, stock_name) in actions {
                if stop_signal.load(Ordering::Relaxed) {
                    break; // Exit if stop signal is set
                }
    
                match action {
                    Action::Buy => {
                        if let Err(e) = self.place_buy_order(&stock_name) {
                            println!("❌ Trader {} failed to buy {}: {}", self.id, stock_name, e);
                        }
                    }
                    Action::Sell => {
                        if let Err(e) = self.place_sell_order(&stock_name) {
                            println!("❌ Trader {} failed to sell {}: {}", self.id, stock_name, e);
                        }
                    }
                }
            }
    
            // Simulate trading frequency
            std::thread::sleep(std::time::Duration::from_secs(5));
        }
        println!("Trader {} has stopped trading.", self.id);
    }
    
    
    

    pub fn select_random_stocks(&self) -> Vec<(Action, String)> {
        let mut rng = rand::thread_rng();

        let stocks = self.stocks.lock().unwrap();
        let num_stocks = rng.gen_range(1..3);
        let selected_stocks: Vec<_> = stocks.choose_multiple(&mut rng, num_stocks).collect();

        let mut preferences = Vec::new();
        for stock in selected_stocks {
            let action = if rng.gen_bool(0.5) {
                // Decide to Buy
                Action::Buy
            } else {
                // Decide to Sell if the trader owns the stock
                if let Some((quantity, _)) = self.portfolio.get(&stock.name) {
                    if *quantity > 0 {
                        Action::Sell
                    } else {
                        Action::Buy
                    }
                } else {
                    Action::Buy
                }
            };

            preferences.push((action, stock.name.clone()));
        }

        preferences
    }
    

    pub fn place_buy_order(
        &mut self,
        stock_name: &str,
    ) -> Result<(), TraderError> {
        let mut rng = rand::thread_rng();
        let buy_trigger = rng.gen_range(50.0..=300.0);
        let quantity = rng.gen_range(10..=30);

        let stock_price = {
            let stocks = self.stocks.lock().unwrap();
            if let Some(stock) = stocks.iter().find(|stock| stock.name == stock_name) {
                Some((quantity, stock.price, buy_trigger))
            } else {
                None
            }
        };

        if let Some((quantity, price, buy_trigger)) = stock_price {
            println!(
                "🛒 Trader {} decided to buy {} shares of {} at a budget of ${:.2} per share.",
                self.id, quantity, stock_name, buy_trigger
            );

            if buy_trigger < 0.25 * price {
                return Err(TraderError::BudgetTooLow {
                    trader_id: self.id,
                    stock_name: stock_name.to_string(),
                });
            }
            self.place_order(stock_name.to_string(), quantity as usize, price, OrderType::Buy);
            Ok(())
        } else {
            Err(TraderError::StockNotFound(stock_name.to_string()))
        }
    }

    
    

    //let entry = self.portfolio.entry(stock_name.to_string()).or_insert((0, 0.0));
    //entry.1 = price;
    //entry.0 += quantity_bought;
    //                //entry.0 -= sell_quantity;
    // if entry.0 == 0 {
    //     self.portfolio.remove(stock_name);
    //     println!("💰 Trader {} decide to sell all shares of {} and no longer holds any.", self.id, stock_name);
    // }

    pub fn place_sell_order(&mut self, stock_name: &str) -> Result<(), TraderError> {
        // Check if the portfolio is empty
        if self.portfolio.is_empty() {
            return Err(TraderError::PortfolioEmpty);
        }
    
        // Check if the trader owns the stock
        if let Some(entry) = self.portfolio.get_mut(stock_name) { //cannot borrow `self.portfolio` as mutable, as it is behind a `&` reference
            let current_quantity = entry.0; // Quantity owned
            let purchase_price = entry.1;  // Price at which the trader owns the stock
    
            // Fetch the current market price for the stock
            let current_market_price = {
                let stocks = self.stocks.lock().unwrap();
                stocks
                    .iter()
                    .find(|stock| stock.name == stock_name)
                    .map(|stock| stock.price)
            };
    
            // Check if the stock exists in the market
            if let Some(market_price) = current_market_price {
                // If the market price is close to the purchase price
                if market_price >= 0.98 * purchase_price && market_price <= 1.02 * purchase_price {
                    let mut rng = rand::thread_rng();
    
                    // Randomly decide whether to sell or not
                    if rng.gen_bool(0.5) {
                        // Decide the quantity to sell: all, half, or quarter
                        let sell_fraction = match rng.gen_range(0..=2) {
                            0 => 1.0,  // all shares
                            1 => 0.75,  // 3/4
                            _ => 0.5, // half
                        };
    
                        let sell_quantity = (current_quantity as f64 * sell_fraction).round() as usize;
    
                        println!(
                            "💰 Trader {} decided to sell {} shares of {} at ${:.2} each (Market Price Close to Stored Price).",
                            self.id, sell_quantity, stock_name, market_price
                        );
    
                        // Place the sell order
                        self.place_order(
                            stock_name.to_string(),
                            sell_quantity,
                            market_price,
                            OrderType::Sell,
                        );
    
                        return Ok(()); // Successfully placed sell order
                    } else {
                        // Trader decides not to sell
                        println!(
                            "💰 Trader {} decided not to sell {} shares of {} at ${:.2} (Market Price Close to Stored Price).",
                            self.id, current_quantity, stock_name, market_price
                        );
                        return Err(TraderError::ProfitIsLow {
                            trader_id: self.id,
                            stock_name: stock_name.to_string(),
                            paid_price: purchase_price,
                            current_price: market_price,
                        });
                    }
                }
    
                // If the market price is not close to the purchase price, sell a fraction of the shares
                let sell_fraction = match rand::thread_rng().gen_range(0..=2) {
                    0 => 1.0,  // Sell all shares
                    1 => 0.5,  // Sell half
                    _ => 0.25, // Sell a quarter
                };
    
                let sell_quantity = (current_quantity as f64 * sell_fraction).round() as usize;
    
                println!(
                    "💰 Trader {} decided to sell {} shares of {} at ${:.2} each. Remaining in portfolio: {} shares if sold.",
                    self.id, sell_quantity, stock_name, market_price, current_quantity - sell_quantity
                );
    
                // Place the sell order
                self.place_order(
                    stock_name.to_string(),
                    sell_quantity,
                    market_price,
                    OrderType::Sell,
                );
    
                Ok(())
            } else {
                // If the stock is not found in the market
                Err(TraderError::StockNotFound(stock_name.to_string()))
            }
        } else {
            // If the stock is not owned by the trader
            Err(TraderError::StockNotFound(stock_name.to_string()))
        }
    }
    
    

    pub fn place_order(
        &self,
        stock_name: String,
        quantity: usize,
        price: f64,
        order_type: OrderType,
    ) {
        let order = Order {
            order_id: format!("O{}", Utc::now().timestamp_millis()),
            trader_id: self.id,
            stock_name: stock_name.clone(),
            quantity,
            price,
            order_type: order_type.clone(),
            timestamp: Utc::now().timestamp_millis(),
        };
    
        let order_json = serde_json::to_string(&order).expect("Failed to serialize order");
    
        tokio::spawn({
            let channel = self.rabbitmq_channel.clone();
            let order_json = order_json.clone();
            async move {
                let _ = channel
                    .basic_publish(
                        "",
                        "orders", // Publish to "orders" queue
                        BasicPublishOptions::default(),
                        order_json.as_bytes(),
                        BasicProperties::default(),
                    )
                    .await
                    .expect("Failed to publish order");
            }
        });
    
        // println!(
        //     "📤 Trader {} published order: {} shares of {} at ${:.2} ({:?})",
        //     self.id, quantity, stock_name, price, order_type
        // );
    }
    
    
    

    pub fn update_portfolio(&mut self, stock_name: String, quantity: usize, price: f64, is_buying: bool) {
        let entry = self.portfolio.entry(stock_name.clone()).or_insert((0, price));
        
        if is_buying {
            // When buying, add quantity and update price
            let total_quantity = entry.0 + quantity;
            let total_cost = (entry.0 as f64 * entry.1) + (quantity as f64 * price);
            entry.0 = total_quantity;
            entry.1 = total_cost;
            println!(
                "📈 Portfolio Update - Buy: Trader {} now holds {} shares of {}",
                self.id, total_quantity, stock_name
            );
        } else {
            // When selling, subtract quantity
            if entry.0 <= quantity {
                // If selling all or more than owned, remove from portfolio
                self.portfolio.remove(&stock_name);
                println!(
                    "📉 Portfolio Update - Sell: Trader {} sold all shares of {}",
                    self.id, stock_name
                );
            } else {
                // Otherwise just reduce quantity, keep same price basis
                entry.0 -= quantity;
                println!(
                    "📉 Portfolio Update - Sell: Trader {} now holds {} shares of {} ",
                    self.id, entry.0, stock_name
                );
            }
        }
    }
}