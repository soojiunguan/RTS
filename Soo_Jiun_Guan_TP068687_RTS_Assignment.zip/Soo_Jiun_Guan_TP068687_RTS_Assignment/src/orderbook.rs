//orderbook.rs
use std::collections::HashMap;
use chrono::Utc;
use std::sync::{Arc, Mutex};
use crate::price::Stock;
use crate::trader::Trader;
use serde::{Serialize, Deserialize};


#[derive(Debug, Serialize, Deserialize)] //the trait bound `OrderType: Deserialize<'_>` is not satisfied for local types consider adding `#[derive(serde::Deserialize)]` to your `OrderType` type for types from other crates check whether the crate offers a `serde` feature flag the following other types implement trait `Deserialize<'de>`: &'a Path &'a [u8] &'a str () (T,) (T0, T1) (T0, T1, T2) (T0, T1, T2, T3) and 191 others
pub struct Order {
    pub order_id: String,
    pub trader_id: usize,
    pub stock_name: String,
    pub quantity: usize,
    pub price: f64,
    pub order_type: OrderType, //the trait bound `OrderType: Deserialize<'_>` is not satisfied for local types consider adding `#[derive(serde::Deserialize)]` to your `OrderType` type for types from other crates check whether the crate offers a `serde` feature flag the following other types implement trait `Deserialize<'de>`: &'a Path &'a [u8] &'a str () (T,) (T0, T1) (T0, T1, T2) (T0, T1, T2, T3) and 191 others
    pub timestamp: i64,
}

#[derive(Debug, PartialEq, Clone, Serialize, Deserialize)] // 添加 Deserialize
pub enum OrderType {
    Buy,
    Sell,
}

pub struct OrderBook {
    orders: Vec<Order>,
    trade_history: Vec<Trade>,
    stocks: Arc<Mutex<Vec<Stock>>>,
    traders: Arc<Mutex<HashMap<usize, Trader>>>,
}

#[derive(Debug)]
pub struct Trade {
    pub trade_id: String,
    pub buyer_id: usize,
    pub seller_id: usize,
    pub stock_name: String,
    pub quantity: usize,
    pub price: f64,
}

impl OrderBook {
    pub fn new(stocks: Vec<Stock>, traders: HashMap<usize, Trader>) -> Self {
        Self {
            orders: Vec::new(),
            trade_history: Vec::new(),
            stocks: Arc::new(Mutex::new(stocks)),
            traders: Arc::new(Mutex::new(traders)), 
        }
    }

    pub fn add_order(&mut self, mut order: Order) {
        order.timestamp = Utc::now().timestamp_millis();
        
        // println!("{}", format!("\n📝 New Order:"));
        // println!("Order ID: {}", order.order_id);
        // println!("Trader {}: {} {} shares of {}", 
        //     order.trader_id,
        //     match order.order_type {
        //         OrderType::Buy => "BUY",
        //         OrderType::Sell => "SELL",
        //     },
        //     order.quantity,
        //     order.stock_name,
        // );
        self.orders.push(order);
        self.match_orders();
    }

    pub fn match_orders(&mut self) {
        let mut matched_order_indices = Vec::new();
        let mut trades = Vec::new();
        let mut orders_to_update = HashMap::new();

        self.orders.sort_by_key(|order| order.timestamp);

        let mut buy_orders: HashMap<String, Vec<(usize, &Order)>> = HashMap::new();
        let mut sell_orders: HashMap<String, Vec<(usize, &Order)>> = HashMap::new();

        for (idx, order) in self.orders.iter().enumerate() {
            match order.order_type {
                OrderType::Buy => buy_orders.entry(order.stock_name.clone())
                    .or_default()
                    .push((idx, order)),
                OrderType::Sell => sell_orders.entry(order.stock_name.clone())
                    .or_default()
                    .push((idx, order)),
            }
        }

        for (stock_name, mut buys) in buy_orders {
            if let Some(mut sells) = sell_orders.get(&stock_name).cloned() {
                sells.sort_by(|a, b| a.1.price.partial_cmp(&b.1.price)
                    .unwrap_or(std::cmp::Ordering::Equal)
                    .then_with(|| a.1.timestamp.cmp(&b.1.timestamp)));

                buys.sort_by(|a, b| b.1.price.partial_cmp(&a.1.price)
                    .unwrap_or(std::cmp::Ordering::Equal)
                    .then_with(|| a.1.timestamp.cmp(&b.1.timestamp)));

                let mut sell_idx = 0;
                'sell_loop: while sell_idx < sells.len() {
                    let (current_sell_idx, sell_order) = sells[sell_idx];
                    
                    if matched_order_indices.contains(&current_sell_idx) {
                        sell_idx += 1;
                        continue;
                    }

                    let available_stocks = if let Ok(stocks) = self.stocks.lock() {
                        stocks.iter()
                            .find(|s| s.name == stock_name)
                            .map(|s| s.quantity)
                            .unwrap_or(0)
                    } else {
                        0
                    };

                    if available_stocks == 0 {
                        // println!("\n⚠️ No available stocks for {}", stock_name);
                        break 'sell_loop;
                    }

                    let mut matched = false;
                    for &(buy_idx, buy_order) in &buys {
                        if matched_order_indices.contains(&buy_idx) {
                            continue;
                        }
                        
                        if buy_order.price >= sell_order.price {
                            let trade_quantity = buy_order.quantity.min(sell_order.quantity);
                            
                            // println!("\n🔄 Matching Order Details:");
                            // println!("Stock Name: {}, Price: {}", stock_name, self.stocks.lock().unwrap().iter().find(|s| s.name == stock_name).unwrap().price);
                            // println!("Sell Order: Trader {} selling {} shares of {} at ${:.2} (Time: {})", 
                            //     sell_order.trader_id, sell_order.quantity, sell_order.stock_name, sell_order.price, sell_order.timestamp);
                                
                            // println!("Buy Order: Trader {} buying {} shares of {}. Budget: ${:.2} (Time: {})", 
                            //     buy_order.trader_id, buy_order.quantity, buy_order.stock_name, buy_order.price, buy_order.timestamp);
                            // println!("➡️ Matched Quantity: {} (Partial Fill: {})", 
                            //     trade_quantity,
                            //     trade_quantity < buy_order.quantity.max(sell_order.quantity)
                            // );

                            let trade = Trade {
                                trade_id: format!("T{}", Utc::now().timestamp_millis()),
                                buyer_id: buy_order.trader_id,
                                seller_id: sell_order.trader_id,
                                stock_name: stock_name.clone(),
                                quantity: trade_quantity,
                                price: sell_order.price,
                            };

                            trades.push(trade);
                            matched = true;

  
                            /// write a function to update portfoiio of each trader in trader.rs
                            /// (trader_id, stock_name, quantity) HashMap<String, (usize, f64)>

                            if buy_order.quantity > trade_quantity {
                                let remaining = buy_order.quantity - trade_quantity;
                                //println!("📌 Buyer {} still needs {} more shares", buy_order.trader_id, remaining);
                                orders_to_update.insert(buy_idx, remaining);
                            } else {
                                matched_order_indices.push(buy_idx);
                            }

                            if sell_order.quantity > trade_quantity {
                                let remaining = sell_order.quantity - trade_quantity;
                                //println!("📌 Seller {} still has {} shares to sell", sell_order.trader_id, remaining);
                                orders_to_update.insert(current_sell_idx, remaining);
                            } else {
                                matched_order_indices.push(current_sell_idx);
                            }

                            if let Ok(mut stocks) = self.stocks.lock() {
                                if let Some(stock) = stocks.iter_mut().find(|s| s.name == stock_name) {
                                    stock.quantity = stock.quantity + trade_quantity;
                                }
                            }

                            // Update traders' portfolios
                            if let Ok(mut traders) = self.traders.lock() {
                                if let Some(buyer) = traders.get_mut(&buy_order.trader_id) {
                                    buyer.update_portfolio(stock_name.clone(), trade_quantity, sell_order.price, true);
                                }
                                
                                if let Some(seller) = traders.get_mut(&sell_order.trader_id) {
                                    seller.update_portfolio(stock_name.clone(), trade_quantity, sell_order.price, false);
                                }
                            }

                            break;
                        }
                    }

                    if !matched {
                        println!("\n⚠️ No match found for sell order: Trader {} selling {} at ${:.2}", 
                         sell_order.trader_id, sell_order.quantity, sell_order.price);
                     }
                    sell_idx += 1;
                }
            } else {
                // println!("\n⚠️ No sell orders available for {}", stock_name);
            }
        }

        for (idx, remaining_quantity) in orders_to_update {
            self.orders[idx].quantity = remaining_quantity;
        }

        matched_order_indices.sort_unstable();
        for index in matched_order_indices.iter().rev() {
            self.orders.remove(*index);
        }

        let mut volume_changes: HashMap<String, usize> = HashMap::new();

        for trade in trades {
            *volume_changes.entry(trade.stock_name.clone()).or_insert(0) += trade.quantity;

            // println!("\n✨ Trade {} executed: {} shares of {} at ${:.2}", 
            //     trade.trade_id,
            //     trade.quantity,
            //     trade.stock_name,
            //     trade.price
            // );
            
            self.trade_history.push(trade);
        }

        // if !volume_changes.is_empty() {
        //     println!("\n📈 Trading Volume Summary:");
        //     for (stock_name, volume) in volume_changes {
        //         println!("  {} : {} shares traded", stock_name, volume);
        //     }
        // }
    }

    // pub fn display_current_orders(&self) {
    //     println!("{}", "\n📊 Current Order Book:");
    //     println!("{}", "Buy Orders:");
    //     for order in self.orders.iter().filter(|o| o.order_type == OrderType::Buy) {
    //         println!("  Trader {} wants {} shares of {} at ${:.2}", 
    //             order.trader_id, order.quantity, order.stock_name, order.price);
    //     }

    //     println!("{}", "Sell Orders:");
    //     for order in self.orders.iter().filter(|o| o.order_type == OrderType::Sell) {
    //         println!("  Trader {} offers {} shares of {} at ${:.2}", 
    //             order.trader_id, order.quantity, order.stock_name, order.price);
    //     }
    // }

    pub fn display_trade_history(&self) {
        println!("{}", "\n📜 Trade History:");
        for trade in &self.trade_history {
            println!("Trade ID: {} - {} shares of {} at ${:.2}", 
                trade.trade_id, trade.quantity, trade.stock_name, trade.price);
            println!("  Buyer: Trader {} | Seller: Trader {}\n", 
                trade.buyer_id, trade.seller_id);
        }
    }
    
    
    
}