//trading_main.rs
mod connection; 
mod trader;     
mod price;      
mod orderbook; 

use lapin::options::{QueueDeclareOptions, BasicConsumeOptions, BasicAckOptions}; 
use lapin::types::FieldTable; // FieldTable for RabbitMQ metadata
use connection::RabbitMQService; // RabbitMQ service abstraction for easy channel creation
use crate::price::Stock; 
use crate::trader::Trader; 
//use crate::orderbook::OrderBook; // OrderBook structure to track orders
use std::sync::{Arc, Mutex}; 
use std::sync::atomic::{AtomicBool, Ordering}; // AtomicBool for managing stop signals across threads
use anyhow::Result; // For error handling
use futures_lite::StreamExt; 
use tokio::task; 
use tokio::time::{Duration, Instant}; // Utilities for measuring elapsed time and delays
use chrono::Local; // Add this import for timestamp formatting


pub async fn consumer_workflow() -> Result<()> {
    // Create RabbitMQ channel and wrap it in an `Arc` for sharing between threads
    let channel = Arc::new(RabbitMQService::new().await.get_channel());

    // Declare the "stock_market" queue to consume stock updates
    channel
        .queue_declare("stock_market", QueueDeclareOptions::default(), FieldTable::default())
        .await?;

    // Declare the "orders" queue to publish and consume orders
    channel
        .queue_declare("orders", QueueDeclareOptions::default(), FieldTable::default())
        .await?;

    // Shared state for stocks and order book, protected with Mutex for safe concurrent access
    let stocks = Arc::new(Mutex::new(vec![])); 
    //let order_book = Arc::new(Mutex::new(OrderBook::new(vec![], HashMap::new())));
    let stop_signal = Arc::new(AtomicBool::new(false)); // Shared stop signal for terminating tasks

    // Clone the RabbitMQ channel for the consumer task
    let consumer_channel = channel.clone();

    // Start consuming messages from the "stock_market" queue
    let mut consumer = consumer_channel
        .basic_consume(
            "stock_market",
            "consumer_tag",
            BasicConsumeOptions::default(),
            FieldTable::default(),
        )
        .await?;

    println!("⏳ Waiting for initial stock update...");

    // Wait until the first stock update is received
    while stocks.lock().unwrap().is_empty() {
        if let Some(delivery) = consumer.next().await {
            let delivery = delivery.expect("Error in consumer");

            // Deserialize received data into stock structures
            let stocks_data: Vec<Stock> = serde_json::from_slice(&delivery.data)?;
            println!("📥 Received initial stock updates");

            // Update the shared stocks data
            {
                let mut shared_stocks = stocks.lock().unwrap();
                *shared_stocks = stocks_data.clone();
            }

            // Acknowledge the message
            channel
                .basic_ack(delivery.delivery_tag, BasicAckOptions::default())
                .await?;
        }
    }

    println!("✅ Initial stock update received. Generating traders...");

    // Initialize traders with unique IDs and share stock data and RabbitMQ channel
    let mut traders = Vec::new();
    for trader_id in 1..=15 {
        let trader_stocks = stocks.clone();
        let trader_channel = channel.clone(); 
        let trader = Trader::new(trader_id, trader_stocks, trader_channel);
        traders.push(trader);
    }

    println!("🔄 Consumer workflow started!");

    // Spawn tasks for each trader to simulate concurrent trading
    let mut trader_handles = vec![];
    for mut trader in traders {
        let trader_stop_signal = stop_signal.clone();
        trader_handles.push(task::spawn(async move {
            trader.start(trader_stop_signal);
        }));
    }

    // Set a runtime limit of 60 seconds for the simulation
    let start_time = Instant::now();
    while start_time.elapsed() < Duration::from_secs(60) {
        if let Some(delivery) = consumer.next().await {
            let delivery = delivery.expect("Error in consumer");

            // Deserialize stock update message
            let stocks_data: Vec<Stock> = serde_json::from_slice(&delivery.data)?;
            let current_time = Local::now();
            println!("[{}] 📥 Received stock updates", current_time.format("%Y-%m-%d %H:%M:%S"));
            

            // Update shared stock data
            {
                let mut shared_stocks = stocks.lock().unwrap();
                *shared_stocks = stocks_data.clone();
            }

            // Acknowledge the message
            channel
                .basic_ack(delivery.delivery_tag, BasicAckOptions::default())
                .await?;
        }
    }

    println!("⏳ Time's up! Stopping the system...");

    // Signal all traders to stop
    stop_signal.store(true, Ordering::Relaxed);

    // Wait for all trader tasks to finish
    for handle in trader_handles {
        if let Err(e) = handle.await {
            eprintln!("Error in trader task: {:?}", e);
        }
    }

    Ok(())
}

#[tokio::main] // Mark the main function as an asynchronous Tokio runtime entry point
async fn main() -> Result<()> {
    if let Err(e) = consumer_workflow().await {
        eprintln!("Error in consumer workflow: {:?}", e); // Log errors during the workflow
        return Err(e);
    }

    Ok(()) // Exit successfully if there are no errors
}
