pub mod connection; // Module for RabbitMQ connection management
pub mod price;       // Module for stock price and metrics
pub mod orderbook;   // Module for order book and trade matching
pub mod trader;      // Module for trader behavior and portfolio management

// Re-export frequently used types and functions for convenience
pub use price::{Stock, StockMetrics, MarketTrend, stock_information};
pub use trader::{Trader, Action, Trigger, TradeAction};
pub use orderbook::{Order, OrderType, OrderBook};
pub use connection::RabbitMQService;
