// SEND AND RECEIVER
// RABBITMQ SERVER
// CONNECTION
use lapin::{
    Connection, 
    Channel, 
    ConnectionProperties,
    options::*,
    types::FieldTable,
    BasicProperties,
};
use serde::Serialize;


pub struct RabbitMQService {
    connection: Connection,
    channel: Channel,
}

impl RabbitMQService {
    pub async fn new() -> Self {
        let addr = "amqp://guest:guest@localhost:5672";
        let connection = Connection::connect(addr, ConnectionProperties::default())
            .await
            .expect("Failed to connect to RabbitMQ");
        let channel = connection
            .create_channel()
            .await
            .expect("Failed to create channel");
        
        Self { connection, channel }
    }

    pub async fn declare_queue(&self, queue_name: &str) {
        self.channel
            .queue_declare(
                queue_name,
                QueueDeclareOptions::default(),
                FieldTable::default(),
            )
            .await
            .expect("Failed to declare queue");
    }

    pub async fn publish<T: Serialize>(&self, queue_name: &str, message: &T) {
        let message = serde_json::to_string(message)
            .expect("Failed to serialize message");

        self.channel
            .basic_publish(
                "",
                queue_name,
                BasicPublishOptions::default(),
                message.as_bytes(),
                BasicProperties::default(),
            )
            .await
            .expect("Failed to publish message");
    }

    pub async fn close(&self) {
        self.connection
            .close(0, "Shutting down")
            .await
            .expect("Failed to close connection");
    }

    pub fn get_channel(&self) -> Channel {
        self.channel.clone()
    }

}