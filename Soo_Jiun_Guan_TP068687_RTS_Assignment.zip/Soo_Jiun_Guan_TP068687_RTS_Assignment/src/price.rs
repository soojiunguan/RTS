//price.rs
use std::fmt;
use rand::Rng;
use prettytable::{Table, row};
use serde::{Serialize, Deserialize};
#[derive(Serialize, Deserialize, Clone, Debug, Eq, Hash, PartialEq)]
pub enum MarketTrend {
    Bull,
    Bear,
    Neutral,
}

impl fmt::Display for MarketTrend {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "{}",
            match self {
                MarketTrend::Bull => "Bull",
                MarketTrend::Bear => "Bear",
                MarketTrend::Neutral => "Neutral",
            }
        )
    }
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct StockMetrics {
    pub volatility: f64,
    pub market_trend: MarketTrend,
}
#[derive(Serialize, Deserialize, Debug, Clone)]
// Struct for stock information
pub struct Stock {
    pub id: u32,
    pub category: String,
    pub name: String,
    pub price: f64,
    pub quantity: usize,
    pub metrics: StockMetrics,
    pub price_history: Vec<f64>,
}

impl Stock {
    pub fn print_stocks(stocks: &Vec<Stock>) {
        let mut table = Table::new();

        // Table headers
        table.add_row(row![
            "ID", "CATEGORY", "NAME", "PRICE", "QUANTITY",
            "VOLATILITY", "MARKET TREND"
        ]);

        // Table rows
        for stock in stocks {
            table.add_row(row![
                stock.id,
                stock.category,
                stock.name,
                format!("${:.2}", stock.price),
                stock.quantity,
                format!("{:.2}", stock.metrics.volatility),
                stock.metrics.market_trend.to_string(),
            ]);
        }

        table.printstd();
    }

    pub fn update_price(&mut self) {
        std::thread::sleep(std::time::Duration::from_secs(5));
        let mut rng = rand::thread_rng();
        let price_change_percentage = rng.gen_range(-0.1..0.1);
        let new_price = self.price * (1.0 + price_change_percentage);
        self.price_history.push(new_price);
        self.price = new_price;

        // Update volatility
        self.metrics.volatility = calculate_volatility(&self.price_history);

        // Update market trend based on price changes
        let price_change = self.price_history.last().unwrap() - self.price_history.first().unwrap();
        self.metrics.market_trend = if price_change > 0.0 {
            MarketTrend::Bull
        } else if price_change < 0.0 {
            MarketTrend::Bear
        } else {
            MarketTrend::Neutral
        };
        
    }
}

pub fn calculate_volatility(price_history: &[f64]) -> f64 {
    if price_history.len() < 2 {
        return 0.0;
    }

    let log_returns: Vec<f64> = price_history.windows(2)
        .map(|window| (window[1] / window[0]).ln())
        .collect();

    let mean = log_returns.iter().sum::<f64>() / log_returns.len() as f64;
    let variance = log_returns.iter()
        .fold(0.0, |acc, &x| acc + (x - mean).powi(2))
        / log_returns.len() as f64;

    variance.sqrt()
}

// Function to summarize market trends
pub fn market_trend_summary(stocks: &[Stock]) -> Vec<(MarketTrend, usize)> {
    use std::collections::HashMap;
    
    let mut trend_counts = HashMap::new();
    
    for stock in stocks {
        *trend_counts.entry(stock.metrics.market_trend.clone()).or_insert(0) += 1;
    }
    
    vec![
        (MarketTrend::Bull, *trend_counts.get(&MarketTrend::Bull).unwrap_or(&0)),
        (MarketTrend::Bear, *trend_counts.get(&MarketTrend::Bear).unwrap_or(&0)),
        (MarketTrend::Neutral, *trend_counts.get(&MarketTrend::Neutral).unwrap_or(&0)),
    ]
}

// Function to get stock categories and their corresponding stocks
fn get_stock_categories() -> Vec<(Vec<&'static str>, &'static str)> {
    let car_stocks = vec![
        "Tesla", "Innova", "Hyundai", "Audi", 
        "Toyota", "Honda", "Volkswagen", "BMW", 
        "Daimler AG (Mercedes-Benz)", "Ferrari"
    ];

    let food_and_beverage_stocks = vec![
        "McDonald", "Coca-Cola", "PepsiCo", "Unilever", "Nestlé", 
        "Kimberly-Clark", "Colgate-Palmolive", "Mondelez International", 
        "Pizza Hut", "Kentucky Fried Chicken"
    ];
    
    // let healthcare_stocks = vec![
    //     "Johnson & Johnson", "Pfizer", "Moderna", "Merck & Co.", 
    //     "UnitedHealth Group", "Abbott Laboratories", "Amgen", 
    //     "Gilead Sciences", "Bristol-Myers Squibb", "Eli Lilly"
    // ];

    // let energy_stocks = vec![
    //     "Exxon Mobil", "Chevron", "ConocoPhillips", "BP", "Shell", 
    //     "TotalEnergies", "NextEra Energy", "Schlumberger", 
    //     "Marathon Petroleum", "Occidental Petroleum"
    // ];

    // let financials_stocks = vec![
    //     "JPMorgan Chase", "Bank of America", "Wells Fargo", "Citigroup", 
    //     "Goldman Sachs", "Morgan Stanley", "American Express", 
    //     "Visa", "Mastercard", "PayPal"
    // ];

    // let communication_services_stocks = vec![
    //     "WhatsApp", "Instagram", "Amazon", "Walt Disney", "Google", 
    //     "Netflix", "Spotify", "Youtube", 
    //     "Zoom Video Communications", "Twitter"
    // ];

    vec![
        (car_stocks, "Car"),
        (food_and_beverage_stocks, "Food and Beverage"),
        // (healthcare_stocks, "Healthcare"),
        // (energy_stocks, "Energy"),
        // (financials_stocks, "Financials"),
        // (communication_services_stocks, "Communication Services"),
    ]
}

// Function to generate price history
fn generate_price_history(base_price: f64, history_length: usize) -> Vec<f64> {
    let mut rng = rand::thread_rng();
    let mut price_history = vec![base_price];
    
    for _ in 0..history_length {
        let price_change_percentage = rng.gen_range(-0.1..0.1);
        let new_price = price_history.last().unwrap() * (1.0 + price_change_percentage);
        price_history.push(new_price);
    }
    
    price_history
}

// Function to determine market trend
fn determine_market_trend(first_price: f64, last_price: f64) -> MarketTrend {
    let price_change = last_price - first_price;
    if price_change > 0.0 {
        MarketTrend::Bull
    } else if price_change < 0.0 {
        MarketTrend::Bear
    } else {
        MarketTrend::Neutral
    }
}

// Main function to generate stock information
pub fn stock_information() -> Vec<Stock> {
    let mut rng = rand::thread_rng();
    let mut stocks = vec![];
    let mut id = 1;
    
    for (stock_list, category) in get_stock_categories() {
        for stock_name in stock_list {
            let base_price = rng.gen_range(100.0..300.0);
            let price_history = generate_price_history(base_price, 10);
            let volatility = calculate_volatility(&price_history);
            let market_trend = determine_market_trend(
                *price_history.first().unwrap(), 
                *price_history.last().unwrap()
            );

            stocks.push(Stock {
                id,
                category: category.to_string(),
                name: stock_name.to_string(),
                price: *price_history.last().unwrap(),
                quantity: rng.gen_range(100..300),
                metrics: StockMetrics {
                    volatility,
                    market_trend,
                },
                price_history,
            });

            id += 1;
        }
    }
    stocks
}