use criterion::{criterion_group, criterion_main, Criterion};
use tokio::runtime::Runtime;
use Soo_Jiun_Guan_RTS_Assignment::{Stock, Trader, stock_information};
use std::sync::{Arc, Mutex};
use std::sync::atomic::{AtomicBool, Ordering};
use tokio::task::spawn_blocking;

fn benchmark_stock_update(c: &mut Criterion) {
    // Generate mock stock data
    let mock_stock_data: Vec<Stock> = stock_information()
        .into_iter()
        .take(5)
        .collect();

    // Shared stocks list
    let shared_stocks = Arc::new(Mutex::new(Vec::new()));

    c.bench_function("stock_update", |b| {
        b.iter(|| {
            // Simulate receiving stock data and updating the shared resource
            let mut stocks = shared_stocks.lock().unwrap();
            *stocks = mock_stock_data.clone(); // Update stocks
        });
    });
}


/// Benchmark the performance of multiple traders' `start` method without reinitializing stocks
fn benchmark_multiple_traders(c: &mut Criterion) {
    let runtime = Runtime::new().unwrap();

    // Initialize stocks once and reuse them
    let stocks = Arc::new(Mutex::new(
        stock_information().into_iter().take(5).collect(),
    ));

    // Mock RabbitMQ channel setup
    let rabbitmq_channel = Arc::new(
        runtime.block_on(Soo_Jiun_Guan_RTS_Assignment::RabbitMQService::new())
            .get_channel(),
    );

    // Pre-create traders once and reuse them
    let num_traders = 15;
    let mut traders = Vec::new();
    for trader_id in 1..=num_traders {
        let trader = Trader::new(trader_id, stocks.clone(), rabbitmq_channel.clone());
        traders.push(trader);
    }

    // Benchmark
    c.bench_function("multiple_traders_start", |b| {
        b.iter(|| {
            runtime.block_on(async {
                let stop_signal = Arc::new(AtomicBool::new(false));
                let mut trader_handles = Vec::new();

                // Spawn tasks for traders
                for mut trader in traders.clone() {
                    let stop_signal_clone = stop_signal.clone();

                    let handle = tokio::spawn(async move {
                        spawn_blocking(move || {
                            trader.start(stop_signal_clone);
                        })
                        .await
                        .unwrap();
                    });

                    trader_handles.push(handle);
                }

                // Simulate a short trading session
                tokio::spawn(async move {
                    tokio::time::sleep(tokio::time::Duration::from_millis(100)).await;
                    stop_signal.store(true, Ordering::Relaxed);
                });

                for handle in trader_handles {
                    handle.await.unwrap();
                }
            });
        });
    });
}

/// Configure benchmarks with shorter durations for testing
fn configure_benchmarks() -> Criterion {
    Criterion::default()
        .configure_from_args() // Allow configuration via CLI
        .sample_size(15) // Reduce the number of samples
        .warm_up_time(std::time::Duration::from_secs(1)) // Reduce warm-up time
        .measurement_time(std::time::Duration::from_secs(5)) // Shorten measurement duration
}

// Register benchmarks
criterion_group! {
    name = benches;
    config = configure_benchmarks();
    targets = benchmark_multiple_traders, benchmark_stock_update
}
criterion_main!(benches);
